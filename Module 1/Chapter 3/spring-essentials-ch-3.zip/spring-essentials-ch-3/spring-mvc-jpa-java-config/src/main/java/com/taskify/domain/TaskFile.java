package com.taskify.domain;

public class TaskFile extends File {

	public TaskFile() {
		super();
	}

	public TaskFile(Long id, String fileName) {
		super(id, fileName);
	}
}
