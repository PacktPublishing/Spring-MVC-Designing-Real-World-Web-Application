package com.springessentials.chapter3.domain;

public class TaskFile extends File {

	public TaskFile() {
		super();
	}

	public TaskFile(Long id, String fileName) {
		super(id, fileName);
	}
}
