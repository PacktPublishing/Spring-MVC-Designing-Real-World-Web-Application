package com.springessentialsbook.chapter4;

public  interface  AutoAnsweringService {

 String answer(ClientInfoBean bean);
}
