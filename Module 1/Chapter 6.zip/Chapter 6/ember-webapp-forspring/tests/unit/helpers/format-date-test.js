import { formatDate } from '../../../helpers/format-date';
import { module, test } from 'qunit';

module('Unit | Helper | format date');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = formatDate(42);
  assert.ok(result);
});
