import { getIfEq } from '../../../helpers/get-if-eq';
import { module, test } from 'qunit';

module('Unit | Helper | get if eq');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = getIfEq(42);
  assert.ok(result);
});
