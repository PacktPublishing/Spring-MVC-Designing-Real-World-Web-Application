
package com.springessentialsbook.chapter7.struts;

public class OrderVO {
	private String orderName;
	private String orderId;

	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

 




}
