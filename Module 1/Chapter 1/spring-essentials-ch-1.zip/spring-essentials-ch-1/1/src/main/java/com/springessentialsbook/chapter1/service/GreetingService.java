package com.springessentialsbook.chapter1.service;

public interface GreetingService {
	void greet(String message);
}