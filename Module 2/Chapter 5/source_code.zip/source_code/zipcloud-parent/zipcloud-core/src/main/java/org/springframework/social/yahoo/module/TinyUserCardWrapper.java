package org.springframework.social.yahoo.module;

public class TinyUserCardWrapper extends YahooObject {

	private TinyUsercard tinyUsercard;

	public TinyUsercard getTinyUsercard() {
		return tinyUsercard;
	}

	public void setTinyUsercard(TinyUsercard tinyUsercard) {
		this.tinyUsercard = tinyUsercard;
	}

}
