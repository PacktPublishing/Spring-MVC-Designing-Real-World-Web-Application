package edu.zipcloud.core.util;

public class UserDetailsUtil {

}
