package edu.zipcloud.cloudstreetmarket.core.enums;

public enum MarketCode {
	EUROPE,
	US,
	AFRICA_MIDDLE_EAST,
	AMERICAS,
	ASIA_PACIFIC;
}
