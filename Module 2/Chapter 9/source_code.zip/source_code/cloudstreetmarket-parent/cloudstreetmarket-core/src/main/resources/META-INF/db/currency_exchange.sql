INSERT INTO currency_exchange (id, name, daily_latest_value, daily_latest_change, daily_latest_change_pc, previous_close, bid, ask) values ('USDGBP=X','USD/GBP', 0.6427, 0, 0, 0, 0.6427, 0.6427);
INSERT INTO currency_exchange (id, name, daily_latest_value, daily_latest_change, daily_latest_change_pc, previous_close, bid, ask) values ('USDEUR=X','USD/EUR', 0.9088, 0, 0, 0, 0.9088, 0.9088);
INSERT INTO currency_exchange (id, name, daily_latest_value, daily_latest_change, daily_latest_change_pc, previous_close, bid, ask) values ('USDINR=X','USD/INR', 63.4174, 0, 0, 0, 63.4174, 63.4174);
INSERT INTO currency_exchange (id, name, daily_latest_value, daily_latest_change, daily_latest_change_pc, previous_close, bid, ask) values ('USDSGD=X','USD/SGD', 1.3505, 0, 0, 0, 1.3505, 1.3505);
INSERT INTO currency_exchange (id, name, daily_latest_value, daily_latest_change, daily_latest_change_pc, previous_close, bid, ask) values ('USDCNY=X','USD/CNY', 6.2066, 0, 0, 0, 6.2066, 6.2066);
