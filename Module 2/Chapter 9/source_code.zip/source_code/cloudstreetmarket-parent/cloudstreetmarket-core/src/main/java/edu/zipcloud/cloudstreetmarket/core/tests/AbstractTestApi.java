package edu.zipcloud.cloudstreetmarket.core.tests;

public abstract class AbstractTestApi extends AbstractTestCloudstreetMarket {
	
	public static final String CONTEXT_PATH = "/api";
	public static final String MONITORING_PATH = "/monitoring/users/";
	public static final String JSON_SUFFIX = ".json";

}
