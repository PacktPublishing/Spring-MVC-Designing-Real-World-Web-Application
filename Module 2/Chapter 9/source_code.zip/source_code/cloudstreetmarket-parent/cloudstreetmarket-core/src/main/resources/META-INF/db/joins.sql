
insert into index_quote(id, date, last, open, previous_close, high, low, index_code) values (1, TIMESTAMP '2014-11-15 09:46:00', 6796.63, 6796.63, 6796.63, 6796.63, 6796.63, '^FTSE');
insert into index_quote(id, date, last, open, previous_close, high, low, index_code) values (2, TIMESTAMP '2014-11-15 10:46:00', 6547.80, 6547.80, 6547.80, 6796.63, 6796.63, '^GDAXI');
