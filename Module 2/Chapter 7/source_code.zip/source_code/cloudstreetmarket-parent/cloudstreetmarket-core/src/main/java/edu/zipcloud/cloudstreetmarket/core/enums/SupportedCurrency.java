package edu.zipcloud.cloudstreetmarket.core.enums;

public enum SupportedCurrency {
	USD,
	EUR,
	INR,
	SGD,
	CNY,
	GBP
}
