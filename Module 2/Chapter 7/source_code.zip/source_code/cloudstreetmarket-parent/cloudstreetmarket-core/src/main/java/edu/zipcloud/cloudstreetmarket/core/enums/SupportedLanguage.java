package edu.zipcloud.cloudstreetmarket.core.enums;

public enum SupportedLanguage {
	EN,
	FR,
	ES
}
