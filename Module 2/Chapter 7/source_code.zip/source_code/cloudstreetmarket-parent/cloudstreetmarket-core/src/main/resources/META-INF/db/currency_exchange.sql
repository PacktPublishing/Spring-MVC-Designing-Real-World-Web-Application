INSERT INTO currency_exchange (id, name, daily_latest_value, daily_latest_change, daily_latest_change_pc, previous_close, high, low) values ('USDGBP=X','USD/GBP', 0.6427, 0, 0, 0, 0, 0);
INSERT INTO currency_exchange (id, name, daily_latest_value, daily_latest_change, daily_latest_change_pc, previous_close, high, low) values ('USDEUR=X','USD/EUR', 0.9088, 0, 0, 0, 0, 0);
INSERT INTO currency_exchange (id, name, daily_latest_value, daily_latest_change, daily_latest_change_pc, previous_close, high, low) values ('USDINR=X','USD/INR', 63.4174, 0, 0, 0, 0, 0);
INSERT INTO currency_exchange (id, name, daily_latest_value, daily_latest_change, daily_latest_change_pc, previous_close, high, low) values ('USDSGD=X','USD/SGD', 1.3505, 0, 0, 0, 0, 0);
INSERT INTO currency_exchange (id, name, daily_latest_value, daily_latest_change, daily_latest_change_pc, previous_close, high, low) values ('USDCNY=X','USD/CNY', 6.2066, 0, 0, 0, 0, 0);
