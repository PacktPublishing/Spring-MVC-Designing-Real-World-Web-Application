package edu.zipcloud.cloudstreetmarket.core.services;

import edu.zipcloud.cloudstreetmarket.core.entities.Quote;

public interface QuoteService<T extends Quote> {
}
