package edu.zipcloud.cloudstreetmarket.core.enums;

import java.io.Serializable;

public enum MarketId implements Serializable{
	EUROPE,
	US,
	AFRICA_MIDDLE_EAST,
	AMERICAS,
	ASIA_PACIFIC,
	INTERNATIONAL;
}
