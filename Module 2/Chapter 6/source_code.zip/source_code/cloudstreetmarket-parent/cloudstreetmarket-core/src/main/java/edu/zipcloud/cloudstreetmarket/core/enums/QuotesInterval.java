package edu.zipcloud.cloudstreetmarket.core.enums;

public enum QuotesInterval {
	
	MINUTE_30, HOUR, DAY, WEEK, MONTH;

}
