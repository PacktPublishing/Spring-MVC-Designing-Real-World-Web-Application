package edu.zipcloud.core.converters;

public interface CsvRecord {
  String[] toStringArray();
}